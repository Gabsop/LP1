#include <iostream>
#include <string>
#include "../include/Estabelecimento.hpp"
void menu(Cliente a, Estabelecimento e);
Cliente criarConta();