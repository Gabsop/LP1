# Supermercado - Atividade 04

- Para usar, basta digitar "make supermercado" e depois digitar "./supermercado"
- É gerado para cada cliente um arquivo com as suas compras com o nome "arquivo_nomedocliente.txt"
- É também gerado um arquivo para o estabelecimento com os produtos vendidos e lucro total com o nome "caixa.csv"

- Caso queira limpar os arquivos .o e arquivos .txt, use o comando "make clean"
- Caso queira colocar tudo em um aquivo zip, use o comando "make zip"

- Feito por Gabriel Santana Oliveira de Paula - 20190037518
- LP1, IMD-UFRN, 2020