#include "../include/Date.h"
#include "../include/Diary.h"

#include <iostream>
#include <sstream>
#include <string>

int main(int argc, char const *argv[])
{
    

    return 0;
}
