#include <string>

using namespace std;

class Produto
{
public:
    int codigo;
    double preco;
    string unidadeMedida;
    int quantidade;
    string nome;
};