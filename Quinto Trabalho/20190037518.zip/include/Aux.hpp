#include <iostream>
#include <string>
#include "../include/Estabelecimento.hpp"
void menu(Cliente a, Estabelecimento e, Fornecedor f);
Cliente criarConta();