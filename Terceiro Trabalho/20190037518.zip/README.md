 # Programa feito na disciplina de Linguagem de Programação I
 - Trata-se de um diário onde o usuário pode adicionar mensagens, que também possui funcionalidades.
 - Pode-se listar as mensagens, procurar por uma mensagem, e etc.
 - Utiliza memória dinâmica para guardar as mensagens, possuindo também um arquivo de configuração para melhor utilização e customização do usuário.
 - O uso é simples, deve-se digitar "make diary" no terminal para compilar o arquivo. Logo após deve-se digitar "./diary interactive" para uma utilização mais simples.
 - Para usuários experientes existes as funções: add, list, e search. Onde o list pode ser personalizado.